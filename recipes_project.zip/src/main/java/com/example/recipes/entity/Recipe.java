package com.example.recipes.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Recipe {

    @Id
    private Integer id;
    private String name;
    private Integer prepTimeMinutes;
    private Integer cookTimeMinutes;
    private Integer servings;
    private String difficulty;

    @ElementCollection
    @CollectionTable(name = "recipe_ingredients", joinColumns = @JoinColumn(name = "recipe_id"))
    @Column(name = "ingredient")
    private List<String> ingredients;

    // Getters and Setters
}
