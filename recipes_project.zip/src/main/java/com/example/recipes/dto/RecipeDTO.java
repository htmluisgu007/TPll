package com.example.recipes.dto;

import java.util.List;

public class RecipeDTO {
    private Integer id;
    private String name;
    private List<String> ingredients;
    private Integer prepTimeMinutes;
    private Integer cookTimeMinutes;
    private Integer servings;
    private String difficulty;

    // Getters and Setters
}
