package com.example.recipes.controller;

import com.example.recipes.dto.RecipeDTO;
import com.example.recipes.entity.Recipe;
import com.example.recipes.service.RecipeService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Scanner;

@Component
public class MenuController implements CommandLineRunner {

    private final RecipeService service;

    public MenuController(RecipeService service) {
        this.service = service;
    }

    @Override
    public void run(String... args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Buscar receita por ID");
            System.out.println("2. Listar receitas salvas");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            int opt = scanner.nextInt();

            switch (opt) {
                case 1:
                    System.out.print("Digite o ID da receita: ");
                    int id = scanner.nextInt();
                    RecipeDTO dto = service.fetchRecipeFromAPI(id);
                    System.out.println("\n--- Receita ---");
                    System.out.println("Nome: " + dto.getName());
                    System.out.println("Ingredientes: " + dto.getIngredients());
                    System.out.println("Dificuldade: " + dto.getDifficulty());
                    System.out.println("Deseja salvar esta receita? (s/n): ");
                    String resposta = scanner.next();
                    if (resposta.equalsIgnoreCase("s")) {
                        service.saveRecipe(dto);
                        System.out.println("Receita salva com sucesso!");
                    }
                    break;
                case 2:
                    List<Recipe> receitas = service.getAllRecipes();
                    System.out.println("\n--- Receitas Salvas ---");
                    for (Recipe r : receitas) {
                        System.out.println(r.getId() + " - " + r.getName());
                    }
                    break;
                case 0:
                    System.out.println("Encerrando...");
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}
