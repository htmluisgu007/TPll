package com.example.fatecpg.JSONPlaceholder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonPlaceholderApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonPlaceholderApplication.class, args);
	}

}
