package com.sistemaescolar.REPOSITORIES;

import com.sistemaescolar.MODELS.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long> {
}
