package com.edu.fatec.pg.receitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceitasjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
